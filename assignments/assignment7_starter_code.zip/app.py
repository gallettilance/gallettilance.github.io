from flask import Flask, render_template, request, url_for, session
import numpy as np
import matplotlib

matplotlib.use("Agg")  # Use 'Agg' backend for non-GUI rendering
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace with your own secret key, need this for session management

def generate_data(N, mu, beta0, beta1, sigma2, S):
    # Generate data and initial plots

    # TODO 1: Generate a random dataset X of size N with values between 0 and 1
    X = None  # Replace with code to generate random values for X

    # TODO 2: Generate a random dataset Y using the specified beta0, beta1, mu, and sigma2
    # Y = beta0 + beta1 * X + mu + error term
    Y = None  # Replace with code to generate Y

    # TODO 3: Fit a linear regression model to X and Y
    model = None  # Initialize the LinearRegression model
    # None  # Fit the model to X and Y
    slope = None  # Extract the slope (coefficient) from the fitted model
    intercept = None  # Extract the intercept from the fitted model

    # TODO 4: Generate a scatter plot of (X, Y) with the fitted regression line
    plot1_path = "static/plot1.png"
    # Replace with code to generate and save the scatter plot

    # TODO 5: Run S simulations to generate slopes and intercepts under the null hypothesis
    slopes = []
    intercepts = []

    for _ in range(S):
        # TODO 6: Generate simulated datasets using the same beta0 and beta1
        X_sim = None  # Replace with code to generate simulated X values
        Y_sim = None  # Replace with code to generate simulated Y values

        # TODO 7: Fit linear regression to simulated data and store slope and intercept
        sim_model = None  # Replace with code to fit the model
        sim_slope = None  # Extract slope from sim_model
        sim_intercept = None  # Extract intercept from sim_model

        slopes.append(sim_slope)
        intercepts.append(sim_intercept)

    # TODO 8: Plot histograms of slopes and intercepts
    plot2_path = "static/plot2.png"
    # Replace with code to generate and save the histogram plot

    # TODO 9: Calculate proportions of slopes and intercepts more extreme than observed
    slope_more_extreme = None  # Replace with code to calculate proportion
    intercept_more_extreme = None  # Replace with code to calculate proportion

    # Return data needed for further analysis
    return X, Y, slope, intercept, plot1_path, plot2_path, slope_more_extreme, intercept_more_extreme


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Get user input from the form
        N = int(request.form["N"])
        mu = float(request.form["mu"])
        sigma2 = float(request.form["sigma2"])
        beta0 = float(request.form["beta0"])
        beta1 = float(request.form["beta1"])
        S = int(request.form["S"])

        # Generate data and initial plots
        X, Y, slope, intercept, plot1, plot2, slope_extreme, intercept_extreme = generate_data(
            N, mu, beta0, beta1, sigma2, S
        )

        # Store data in session
        session['X'] = X.tolist()
        session['Y'] = Y.tolist()
        session['slope'] = slope
        session['intercept'] = intercept
        session['slope_extreme'] = slope_extreme
        session['intercept_extreme'] = intercept_extreme
        session['N'] = N
        session['mu'] = mu
        session['sigma2'] = sigma2
        session['beta0'] = beta0
        session['beta1'] = beta1
        session['S'] = S

        # Return render_template with variables
        return render_template(
            "index.html",
            plot1=plot1,
            plot2=plot2,
            slope_extreme=slope_extreme,
            intercept_extreme=intercept_extreme,
            N=N,
            mu=mu,
            sigma2=sigma2,
            beta0=beta0,
            beta1=beta1,
            S=S,
        )
    return render_template("index.html")


@app.route("/generate", methods=["POST"])
def generate():
    # This route handles data generation (same as above)
    return index()


@app.route("/hypothesis_test", methods=["POST"])
def hypothesis_test():
    # Retrieve data from session
    N = session.get('N')
    mu = session.get('mu')
    sigma2 = session.get('sigma2')
    beta0 = session.get('beta0')
    beta1 = session.get('beta1')
    S = session.get('S')
    X = np.array(session.get('X'))
    Y = np.array(session.get('Y'))
    slope = session.get('slope')
    intercept = session.get('intercept')
    slope_extreme = session.get('slope_extreme')
    intercept_extreme = session.get('intercept_extreme')

    parameter = request.form.get("parameter")
    test_type = request.form.get("test_type")

    # Set hypothesized_value based on the parameter from data generation
    if parameter == "slope":
        hypothesized_value = beta1
        observed_stat = slope
    elif parameter == "intercept":
        hypothesized_value = beta0
        observed_stat = intercept
    else:
        hypothesized_value = None
        observed_stat = None

    # TODO 10: Perform hypothesis testing based on the inputs
    # Use the data generation parameters and the selected parameter to test

    # TODO 11: Implement the hypothesis testing simulations
    # You will need to:
    # - Generate simulated datasets under the null hypothesis
    # - Fit models and collect the statistics
    # - Compare with the observed statistic
    # - Implement p-value calculations (students will implement this)

    # Initialize list to store simulated parameter estimates under null hypothesis
    simulated_stats = []

    for _ in range(S):
        # TODO 12: Generate simulated datasets under the null hypothesis
        X_sim = None  # Generate simulated X values
        Y_sim = None  # Generate simulated Y values under null hypothesis

        # TODO 13: Fit linear regression to simulated data and extract parameter
        sim_model = None  # Fit model
        sim_stat = None  # Extract parameter being tested

        simulated_stats.append(sim_stat)

    # TODO 14: Calculate p-value based on test type
    p_value = None  # Students will implement this

    # TODO 15: If p_value is very small (e.g., <= 0.0001), set fun_message to a fun message
    fun_message = None  # Students will implement this

    # TODO 16: Plot histogram of simulated statistics
    plot3_path = "static/plot3.png"
    # Replace with code to generate and save the plot

    # Return results to template
    return render_template(
        "index.html",
        plot1="static/plot1.png",
        plot2="static/plot2.png",
        plot3=plot3_path,
        parameter=parameter,
        observed_stat=observed_stat,
        hypothesized_value=hypothesized_value,
        N=N,
        mu=mu,
        sigma2=sigma2,
        beta0=beta0,
        beta1=beta1,
        S=S,
        slope_extreme=slope_extreme,
        intercept_extreme=intercept_extreme,
        # TODO 17: Uncomment the following lines when implemented
        # p_value=p_value,  # Students will include this when implemented
        # fun_message=fun_message,  # Students will include this when implemented
    )



@app.route("/confidence_interval", methods=["POST"])
def confidence_interval():
    # Retrieve data from session
    N = session.get('N')
    mu = session.get('mu')
    sigma2 = session.get('sigma2')
    beta0 = session.get('beta0')
    beta1 = session.get('beta1')
    S = session.get('S')
    X = np.array(session.get('X'))
    Y = np.array(session.get('Y'))
    slope = session.get('slope')
    intercept = session.get('intercept')
    slope_extreme = session.get('slope_extreme')
    intercept_extreme = session.get('intercept_extreme')

    parameter = request.form.get("parameter")
    confidence_level = float(request.form.get("confidence_level"))

    # Generate observed statistic
    observed_stat = slope if parameter == "slope" else intercept

    # TODO 18: Perform bootstrap simulations to calculate confidence intervals
    # Use the data generated earlier and the selected parameter

    # Initialize list to store bootstrap parameter estimates
    bootstrap_stats = []

    for _ in range(S):
        # TODO 19: Generate bootstrap sample by resampling with replacement
        indices = None  # Generate random indices for resampling
        X_bootstrap = None  # Resample X based on indices
        Y_bootstrap = None  # Resample Y based on indices

        # TODO 20: Fit linear regression to bootstrap sample and extract parameter
        bootstrap_model = None  # Fit model
        boot_stat = None  # Extract parameter being tested

        bootstrap_stats.append(boot_stat)

    # TODO 21: Calculate confidence interval based on bootstrap_stats and confidence_level
    conf_interval = None  # Use np.percentile to determine the confidence interval

    # TODO 22: Plot bootstrap distribution with confidence interval
    plot4_path = "static/plot4.png"
    # Replace with code to generate and save the plot

    # Return results to template
    return render_template(
        "index.html",
        plot1="static/plot1.png",
        plot2="static/plot2.png",
        plot4=plot4_path,
        parameter=parameter,
        confidence_level=confidence_level,
        conf_interval=conf_interval,
        observed_stat=observed_stat,
        N=N,
        mu=mu,
        sigma2=sigma2,
        beta0=beta0,
        beta1=beta1,
        S=S,
        slope_extreme=slope_extreme,
        intercept_extreme=intercept_extreme,
    )


if __name__ == "__main__":
    app.run(debug=True)