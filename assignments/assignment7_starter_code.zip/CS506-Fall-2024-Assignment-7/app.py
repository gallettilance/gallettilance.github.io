from flask import Flask, render_template, request, url_for
import numpy as np
import matplotlib

matplotlib.use("Agg")  # Use 'Agg' backend for non-GUI rendering
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

app = Flask(__name__)


def generate_plots(
    N,
    mu,
    sigma2,
    S,
    parameter=None,
    hypothesized_value=None,
    test_type=None,
    confidence_level=None,
):
    # ------------------------------
    # Assignment 6 Code
    # ------------------------------

    # TODO 1 (Assignment 6): Generate a random dataset X of size N with values between 0 and 1
    # and a random dataset Y with normal additive error (mean mu, variance sigma^2).
    # Hint: Use numpy's random functions to generate values for X and Y
    X = None  # Replace with code to generate random values for X
    Y = None  # Replace with code to generate random values for Y with specified mean and variance

    # TODO 2 (Assignment 6): Fit a linear regression model to X and Y
    # Hint: Use Scikit-Learn's LinearRegression
    model = None  # Initialize the LinearRegression model
    # None  # Fit the model to X and Y
    slope = None  # Extract the slope (coefficient) from the fitted model
    intercept = None  # Extract the intercept from the fitted model

    # TODO 3 (Assignment 6): Generate a scatter plot of (X, Y) with the fitted regression line
    # - Label the x-axis as "X" and the y-axis as "Y"
    # - Add a title showing the regression line equation using the slope and intercept values
    # - Save the plot to "static/plot1.png" using plt.savefig()
    plot1_path = "static/plot1.png"
    # Replace the above TODO 3 block with code to generate and save the plot

    # TODO 4 (Assignment 6): Run S simulations to generate slopes and intercepts
    slopes = []  # Replace with code to initialize empty list for slopes
    intercepts = []  # Replace with code to initialize empty list for intercepts

    for _ in range(S):
        # TODO 5 (Assignment 6): Generate simulated datasets and compute slope and intercept
        X_sim = None  # Replace with code to generate simulated X values
        Y_sim = None  # Replace with code to generate simulated Y values

        # TODO 6 (Assignment 6): Fit linear regression to simulated data and store slope and intercept
        sim_model = None  # Replace with code to fit the model
        sim_slope = None  # Extract slope from sim_model
        sim_intercept = None  # Extract intercept from sim_model

        slopes.append(sim_slope)  # Append to slopes list
        intercepts.append(sim_intercept)  # Append to intercepts list

    # TODO 7 (Assignment 6): Plot histograms of slopes and intercepts
    # - Overlay histograms for slopes and intercepts
    # - Mark the slope and intercept from the original dataset
    # - Save the plot to "static/plot2.png"
    plot2_path = "static/plot2.png"
    # Replace with code to generate and save the histogram plot

    # TODO 8 (Assignment 6): Calculate proportions of slopes and intercepts more extreme than observed
    slope_more_extreme = None  # Replace with code to calculate proportion
    intercept_more_extreme = None  # Replace with code to calculate proportion

    # ------------------------------
    # Assignment 7 Code
    # ------------------------------

    # Only proceed with Assignment 7 if hypothesis testing and confidence interval inputs are provided
    if parameter and hypothesized_value is not None and test_type and confidence_level:
        # ------------------------------
        # Hypothesis Testing
        # ------------------------------

        # TODO 9 (Assignment 7): Initialize list to store simulated parameter estimates under null hypothesis
        simulated_stats = []  # Empty list to store simulated parameter estimates

        for _ in range(S):
            # TODO 10 (Assignment 7): Generate simulated datasets under the null hypothesis
            # - If testing the slope: Y_sim = hypothesized_value * X + error
            # - If testing the intercept: Y_sim = hypothesized_value + error
            X_sim = None  # Replace with code to generate simulated X values
            Y_sim = None  # Replace with code to generate simulated Y values based on parameter

            # TODO 11 (Assignment 7): Fit linear regression to simulated data and extract parameter
            sim_model = None  # Replace with code to fit the model
            sim_stat = None  # Extract the parameter being tested (slope or intercept)

            simulated_stats.append(sim_stat)  # Append to simulated_stats list

        # TODO 12 (Assignment 7): Calculate the observed statistic from original data
        observed_stat = None  # Use slope or intercept based on parameter

        # TODO 13 (Assignment 7): Calculate p-value based on test type
        # - For '>', p-value = proportion of simulated_stats >= observed_stat
        # - For '<', p-value = proportion of simulated_stats <= observed_stat
        # - For '!=', p-value = proportion of simulated_stats as extreme as observed_stat
        p_value = None  # Replace with code to calculate p-value

        # TODO 14 (Assignment 7): Plot histogram of simulated statistics
        # - Highlight area providing evidence against null hypothesis
        # - Mark observed_stat and hypothesized_value on the plot
        plot3_path = "static/plot3.png"
        # Replace with code to generate and save the hypothesis testing histogram plot

        # ------------------------------
        # Confidence Intervals
        # ------------------------------

        # TODO 15 (Assignment 7): Initialize list to store bootstrap parameter estimates
        bootstrap_stats = []  # Empty list to store bootstrap estimates

        for _ in range(S):
            # TODO 16 (Assignment 7): Generate bootstrap sample by resampling with replacement
            indices = (
                None  # Replace with code to generate random indices for resampling
            )
            X_bootstrap = None  # Replace with code to resample X based on indices
            Y_bootstrap = None  # Replace with code to resample Y based on indices

            # TODO 17 (Assignment 7): Fit linear regression to bootstrap sample and extract parameter
            bootstrap_model = None  # Replace with code to fit the model
            boot_stat = None  # Extract the parameter being tested (slope or intercept)

            bootstrap_stats.append(boot_stat)  # Append to bootstrap_stats list

        # TODO 18 (Assignment 7): Calculate confidence interval based on bootstrap_stats and confidence_level
        lower_percentile = None  # Calculate lower percentile
        upper_percentile = None  # Calculate upper percentile
        conf_interval = None  # Use np.percentile to determine the confidence interval

        # TODO 19 (Assignment 7): Plot bootstrap distribution with confidence interval
        # - Mark observed_stat and confidence interval bounds on the plot
        plot4_path = "static/plot4.png"
        # Replace with code to generate and save the confidence interval plot

    else:
        # If Assignment 7 inputs are not provided, set related variables to None
        plot3_path = None
        p_value = None
        plot4_path = None
        conf_interval = None
        observed_stat = None

    # Return all necessary variables for rendering the template
    return (
        plot1_path,
        plot2_path,
        slope_more_extreme,
        intercept_more_extreme,
        plot3_path,
        p_value,
        plot4_path,
        conf_interval,
        observed_stat,
        parameter,
        hypothesized_value,
        test_type,
        confidence_level,
    )


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Get user input from the form
        N = int(request.form["N"])
        mu = float(request.form["mu"])
        sigma2 = float(request.form["sigma2"])
        S = int(request.form["S"])

        # Get Assignment 7 inputs if provided
        parameter = request.form.get("parameter")  # 'slope' or 'intercept'
        hypothesized_value = request.form.get("hypothesized_value")
        test_type = request.form.get("test_type")  # '>', '<', or '!='
        confidence_level = request.form.get("confidence_level")  # e.g., 95

        # Convert to appropriate types if not None
        if hypothesized_value:
            hypothesized_value = float(hypothesized_value)
        else:
            hypothesized_value = None

        if confidence_level:
            confidence_level = float(confidence_level)
        else:
            confidence_level = None

        # Generate plots and results
        (
            plot1,
            plot2,
            slope_extreme,
            intercept_extreme,
            plot3,
            p_value,
            plot4,
            conf_interval,
            observed_stat,
            parameter,
            hypothesized_value,
            test_type,
            confidence_level,
        ) = generate_plots(
            N, mu, sigma2, S, parameter, hypothesized_value, test_type, confidence_level
        )

        return render_template(
            "index.html",
            plot1=plot1,
            plot2=plot2,
            slope_extreme=slope_extreme,
            intercept_extreme=intercept_extreme,
            plot3=plot3,
            p_value=p_value,
            plot4=plot4,
            conf_interval=conf_interval,
            observed_stat=observed_stat,
            parameter=parameter,
            hypothesized_value=hypothesized_value,
            test_type=test_type,
            confidence_level=confidence_level,
        )
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)
